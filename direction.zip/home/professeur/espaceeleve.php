<?php
session_start();
?>

<?php include("../../include/navbar3.php"); ?>

<link rel="stylesheet" href="../../css/testpencil.css?<?= rand(); ?>">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

<style>
  body {
    background: url("../../images/panneleleveee.jpg"); no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    background-position: top 100px;
  }
</style>

<div class="container">
  <div class="col-md-8 mx-auto" style="padding-top: 250px;">
    <table class="table">
      <thead>
        <tr class="table-info">
          <th scope="col">#</th>
          <th scope="col">Nom</th>
          <th scope="col">Prénom</th>
          <th scope="col">Classe</th>
          <th scope="col">Absence</th>
          <th scope="col">Retard</th>
          <th scope="col">Password</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $pdo = new PDO('mysql:host=localhost;dbname=projetphp', 'root', null);
        $query = $pdo->prepare("SELECT * FROM `etudiant`");
        $query->execute();
        $data = $query->fetchAll(2);

        foreach($data as $direction) {
        ?>
        <tr >
          <th scope="row"><?= $direction['id']; ?></th>
          <td><?= $direction['nom']; ?></td>
          <td><?= $direction['prenom']; ?></td>
          <td><?= $direction['classe']; ?></td>
          <td><?= $direction['absence']; ?></td>
          <td><?= $direction['retard']; ?></td>
          <td><?= $direction['password']; ?></td>

          <td>
            <a href="eleve_edit.php?id=<?= $direction['id']; ?>"><button type="button" class="btn btn-transparent btn-sm"><i class="fa fa-edit"></i></button></a>
            <a href="eleve_delete.php?delete=<?= $direction['id']; ?>"><button type="button" class="btn btn-transparent btn-sm"><i class="fas fa-ban"></i></button></a>
            <a href="eleve_abs.php?id=<?= $direction['id']; ?>"><button title="Absent" type="button" class="btn btn-transparent btn-sm"><i class="fas fa-ghost"></i></button></a>
            <a href="eleve_retard.php?id=<?= $direction['id']; ?>"><button title="Retard" type="button" class="btn btn-transparent btn-sm"><i class="fas fa-bed"></i></button></a>

          </td>
        </tr>
      <?php } ?>

      </tbody>
    </table>
    <a href="eleve_add.php"><button type="button" class="btn btn-transparent btn-sm"><i class="fas fa-plus"></i> Ajout</button></a>


  </div>

</div>
</div>



<script src="js/testpencil.js"></script>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/font.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body></html>
