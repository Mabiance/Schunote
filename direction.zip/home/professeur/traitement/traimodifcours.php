<?php
if(isset($_POST['matiere'])){
  include_once '../../../classes/class.php';
  $id = $_GET['id'];
  $matiere = $_POST['matiere'];
  $classe = $_POST['classe'];
  $contenu = $_POST['contenu'];
  $inscrire = new prof(['id'=>$id,'matiere'=>$matiere,'classe'=>$classe,'contenu'=>$contenu]);
  $inscrire->modifiercours();
}
else{
  echo 'nope';
}

?>
