<?php
if(isset($_POST['matiere'])){
  include_once '../../../classes/class.php';
  $matiere = $_POST['matiere'];
  $contenu = $_POST['contenu'];
  $classe = $_POST['classe'];
  $id = $_GET['id'];
  $inscrire = new prof(['matiere'=>$matiere,'contenu'=>$contenu,'classe'=>$classe,'id'=>$id]);
  $inscrire->ajoutercours();
  setcookie('user','dir',time()+120);
}
else{
  echo 'nope';
}

?>
