<?php
session_start();
include_once "../../include/navbar4.php";
?>
<link rel="stylesheet" href="css/testpencil.css?<?= rand(); ?>">
<style>
.pencil {
  height: 680px !important;
}
</style>

  <div class="row">
    <center><br><br>
    <img src="../../images/eleve.png" width="100%" height="650" class="d-inline-block align-top" alt="">
    </center>
  </div>

  <div class="d-block mx-auto col-md-8 col-xs-6">

  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/font.js"></script>
  <script src="js/testpencil.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
