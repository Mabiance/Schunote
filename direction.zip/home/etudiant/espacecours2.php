<?php
session_start();
?>

<?php include("../../include/navbar4.php"); ?>
<meta charset="utf-8" />
<link rel="stylesheet" href="css/testpencil.css?<?= rand(); ?>">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

<style>
  body {
    background: url("../../images/voscours.jpg"); no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    background-position: top 100px;
  }
</style>

<div class="container">
<div style="padding-top: 30px;" class="d-block mx-auto">

  <div class="col-md-8 mx-auto" style="padding-top: 250px;">
    <table class="table">
      <thead>
        <tr class="table-info">

          <th scope="col">Classe</th>
          <th scope="col">Matiere</th>
          <th scope="col">Contenu</th>

        </tr>
      </thead>
      <tbody>
        <?php
        $classe = $_GET['classe'];
        $pdo = new PDO('mysql:host=localhost;dbname=projetphp', 'root', null);
        $query = $pdo->prepare("SELECT * FROM `cours` WHERE classe=:classe");
        $query->execute(['classe'=>$classe]);
        $data = $query->fetchAll(2);

        foreach($data as $cours) {
        ?>
        <tr >

          <td><?= $cours['classe']; ?></td>
          <td><?= $cours['matiere']; ?></td>
          <td><?= $cours['contenu']; ?></td>
        </tr>
      <?php } ?>

      </tbody>
    </table>



  </div>

</div>
</div>



<script src="js/testpencil.js"></script>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/font.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body></html>
