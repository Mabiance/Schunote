<?php
  header('location: ../home/etudiant/');
?>
