<?php
if(isset($_GET['delete'])){
  include_once '../../classes/class.php';
  $id = $_GET['delete'];
  $inscrire = new direction(['id'=>$id]);
  $inscrire->supprimeretu();
  setcookie('user','dir',time()+120);
}
else{
  echo 'nope';
}

?>
