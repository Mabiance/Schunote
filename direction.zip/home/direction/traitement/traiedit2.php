<?php
if(isset($_POST['password'])){
  include_once '../../../classes/class.php';
  $password = $_POST['password'];
  $id = $_GET['id'];
  $inscrire = new prof(['password'=>$password,'id'=>$id]);
  $inscrire->dirmodifierprof();
  setcookie('user','dir',time()+120);
}
else{
  echo 'nope';
}

?>
