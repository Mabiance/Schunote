<?php
if(isset($_POST['password'])){
  include_once '../../../classes/class.php';
  $password = $_POST['password'];
  $id = $_GET['id'];
  $classe = $_POST['classe'];
  $inscrire = new prof(['password'=>$password,'id'=>$id,'classe'=>$classe]);
  $inscrire->modifieretu();
  setcookie('user','dir',time()+120);
}
else{
  echo 'nope';
}

?>
