<?php
if(isset($_POST['nom'])){
  include_once '../../../classes/class.php';
  $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];
  $password = $_POST['password'];
  $inscrire = new prof(['nom'=>$nom,'prenom'=>$prenom,'password'=>$password]);
  $inscrire->dirajouterdir();
  setcookie('user','dir',time()+120);
}
else{
  echo 'nope';
}

?>
