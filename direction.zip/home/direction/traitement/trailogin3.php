<?php
if(isset($_POST['nom'])){
  include_once '../../../classes/class.php';
  $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];
  $classe = $_POST['classe'];
  $password = $_POST['password'];
  $inscrire = new etudiant(['nom'=>$nom,'prenom'=>$prenom,'password'=>$password,'classe'=>$classe]);
  $inscrire->ajouteretu();
  setcookie('user','dir',time()+120);
}
else{
  echo 'nope';
}

?>
