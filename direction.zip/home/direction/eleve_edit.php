<?php
session_start();
include("../../include/navbar2.php");
?>

<link rel="stylesheet" href="../../css/testpencil.css?<?= rand(); ?>">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<style>
  body {
    background: url("../../images/panneleleve.jpg"); no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    background-position: top 100px;
    height: 100%;
    width: 100%;
  }
</style>

<div style="padding-top: 290px;" class="d-block mx-auto col-md-4 col-xs-2">

    <div class="form-area text-center">
        <form id="form-contact" role="form" method="POST" action="traitement/trai_edit_eleve.php?id=<?=$_GET['id'];?>">

            <br style="clear:both">

            <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <label class="input-group-text" for="inputGroupSelect01">Classe</label>
                </div>

                <select class="custom-select" id="inputGroupSelect01" name="classe">
                    <option>Bleue</option>
                    <option>Verte</option>
                    <option>Violette</option>
                    <option>Jaune</option>
                  </select>
              </div>

            <div class="form-group">
                <input type="password" class="form-control" id="password" name="password" placeholder="Mot de passe" required>
            </div>

            <button type="submit" id="submit" name="submit" class="btn btn-secondary">Editer</button>
        </form>
    </div>

</div>

<script src="js/testpencil.js"></script>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/font.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>
</html>
