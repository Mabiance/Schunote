<?php
if(isset($_GET['id'])){
  include_once '../../classes/class.php';
  $id = $_GET['id'];
  $inscrire = new direction(['id'=>$id]);
  $inscrire->dirsupprimerprof();
  setcookie('user','dir',time()+120);
}
else{
  echo 'nope';
}

?>
