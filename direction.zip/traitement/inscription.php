<?php
if(isset($_POST['nom'])){
  include_once '../classes/class.php';
  $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];
  $password = $_POST['password'];
  $classe=$_POST['classe'];
  $inscrire = new etudiant(['nom'=>$nom,'prenom'=>$prenom,'password'=>$password,'classe'=>$classe]);
  $inscrire->inscription();
  setcookie('user','etu',time()+120);
  header('Location: ../home/etudiant/');
}
else{
  if(isset($_COOKIE['user']))
  {
    header('location: ../eleve.php');
  }
  else{
    header('location: ../');
  }
}

?>
