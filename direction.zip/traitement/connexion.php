<?php
if(isset($_POST['nom'])){
  include_once '../classes/class.php';
  $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];
  $password = $_POST['password'];
  $choix = $_POST['choix'];
  if($choix==1){
    $connexion = new etudiant(['nom'=>$nom,'prenom'=>$prenom,'password'=>$password]);
    $type = 'etu';
    $connexion->connexion($type);
  }
  if($choix==0){
    $connexion = new prof(['nom'=>$nom,'prenom'=>$prenom,'password'=>$password]);
    $type = 'prof';
    $ok = $connexion->connexion($type);
  }
  if($choix==2){
    $connexion = new direction(['nom'=>$nom,'prenom'=>$prenom,'password'=>$password]);
    $type = 'dir';
    $connexion->connexion($type);
  }
}
else{
  if(isset($_COOKIE['user']))
  {
    header('location: ../home');
  }
  else{
    header('location: ../');
  }
}

?>
