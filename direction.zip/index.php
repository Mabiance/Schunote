<?php
session_start();
include("include/navbar1.php");
?>
<link rel="stylesheet" href="css/testpencil.css?<?= rand(); ?>">
<style>
.pencil {
  height: 680px !important;
}
</style>

  <div class="row">
    <center>
    <img src="images/background.png" width="100%" height="650" class="d-inline-block align-top" alt="">
    </center>
  </div>
  <div class="d-block mx-auto col-md-8 col-xs-6">
  <?php

  include("include/footer.php");
  ?>
