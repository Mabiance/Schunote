

<div class="row">

<br><br>
<div id="pencilcase">
<div class="pencil red">
<div class="top"></div>
<div class="left"></div>
<div class="center"></div>
<div class="right"></div>
</div>
<div class="pencil orange">
<div class="top"></div>
<div class="left"></div>
<div class="center"></div>
<div class="right"></div>
</div>
<div class="pencil yellow">
<div class="top"></div>
<div class="left"></div>
<div class="center"></div>
<div class="right"></div>
</div>
<div class="pencil green">
<div class="top"></div>
<div class="left"></div>
<div class="center"></div>
<div class="right"></div>
</div>
<div class="pencil blue">
<div class="top"></div>
<div class="left"></div>
<div class="center"></div>
<div class="right"></div>
</div>
<div class="pencil indigo">
<div class="top"></div>
<div class="left"></div>
<div class="center"></div>
<div class="right"></div>
</div>
<div class="pencil violet">
<div class="top"></div>
<div class="left"></div>
<div class="center"></div>
<div class="right"></div>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script src="js/texte.js"></script>
</div>
</div>

</div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/font.js"></script>
<script src="js/testpencil.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
