<?php
session_start();
?>

<?php include("../include/navbar.php"); ?>

<link rel="stylesheet" href="../css/testpencil.css?<?= rand(); ?>">

<style>
  body {
    background: url("../images/inscription.jpg"); no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    height: 100%;
    width: 100%;
  }
</style>


<div style="padding-top: 200px;" class="d-block mx-auto col-md-4 col-xs-2">

    <div class="form-area text-center">
        <form id="form-contact" role="form" action="../traitement/inscription.php" method="post">
            <br style="clear:both">
            <div class="form-group">
                <input type="text" class="form-control" id="nom" name="nom" placeholder="Nom" required>
            </div>
            <div class="input-group mb-3">
              <div class="input-group-prepend">
                <label class="input-group-text" for="inputGroupSelect01">Classe</label>
              </div>
              <select class="custom-select" id="inputGroupSelect01" name="classe">
                <option selected value="bleue">Bleue</option>
                <option value="verte">Verte</option>
                <option value="violette">Violette</option>
                <option value="jaune">Jaune</option>
              </select>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prénom" required>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="password" name="password" placeholder="Mot de passe" required>
            </div>
          <button type="submit" id="submit" name="submit" class="btn btn-secondary">Inscription</button>
        </form>
    </div>
</div>

<div class="d-block mx-auto col-md-8 col-xs-6" style="padding-top: 400px;">
<?php include("../include/footer.php"); ?>
