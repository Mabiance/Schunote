<?php
//test interface

interface test{
  public function connexion($type);
  public function inscription();
  public function dirlisteetudiant();
  public function dirlisteetudiantparclasse();
  public function ajoutercours();
  public function modifiercours();
  public function dirabsenceprof();
  public function absenceeleve();
  public function retardeleve();
  public function dirajouterprof();
  public function dirajouterdir();
  public function ajouteretu();
  public function dirsupprimerprof();
  public function dirsupprimerdir();
  public function supprimeretu();
  public function supprimercours();
  public function dirmodifierprof();
  public function modifieretu();
  public function dirmodifierdir();
}

//création de la classe utilisateur + attributs + guetters/setters + méthodes
  class utilisateur implements test{
    protected $_Nom;
    protected $_Prenom;
    protected $_Classe;
    protected $_Password;
    protected $_bdd;
    protected $_Id;
    protected $_Matiere;
    protected $_Contenu;

    //setters et guetters des attributs de la classe utilisateur
    public function setNom($Nom){
      $this->_Nom=$Nom;
    }
    public function getNom(){
      return $this->_Nom;
    }

    public function setMatiere($Matiere){
      $this->_Matiere=$Matiere;
    }
    public function getMatiere(){
      return $this->_Matiere;
    }

    public function setContenu($Contenu){
      $this->_Contenu=$Contenu;
    }
    public function getContenu(){
      return $this->_Contenu;
    }

    public function setClasse($Classe){
      $this->_Classe=$Classe;
    }
    public function getClasse(){
      return $this->_Classe;
    }

    public function setPrenom($Prenom){
      $this->_Prenom=$Prenom;
    }
    public function getPrenom(){
      return $this->_Prenom;
    }

    public function setPassword($Password){
      $this->_Password=$Password;
    }
    public function getPassword(){
      return $this->_Password;
    }

    public function getType($Type){
      return $this->_Type;
    }
    //connexion à la base stockée dans l'attribut bdd
    public function setBdd(){
      $this->_bdd = new PDO('mysql:host=localhost;dbname=projetphp','root','');
    }

    public function setId($Id){
      $this->_Id = $Id;
    }

    // Un tableau de données doit être passé à la fonction (d'où le préfixe « array »).
    public function hydrate(array $donnee){
      foreach($donnee as $k=>$u){
        $methode='set'.ucfirst($k);     // On récupère le nom du setter correspondant à l'attribut.
        if(method_exists($this,$methode)){ // Si le setter correspondant existe.
          $this->$methode($u); //on appelle le setter
        }
      }
    }
    //creation de ma fonction construct hydrate
    public function __construct(array $donnee){
      $this->hydrate($donnee);
    }

    //Fonction qui permet la connexion d'un etudiant, un professeur ou un membre de la direction
    public function connexion($type){
      $this->setBdd();
      $nom = $this->_Nom;
      $pnom = $this->_Prenom;
      if($type=='etu'){
        $requete = $this->_bdd->prepare('SELECT password, classe, id FROM etudiant WHERE nom=:nom AND prenom=:pnom ');
        $pass = $requete->execute(['nom'=>$nom,'pnom'=>$pnom]);
        $pass2 = $requete->fetchall();
        $id = $pass2['0']['id'];
        if($pass2['0']['password']==$this->_Password){
          $classe = $pass2['0']['classe'];
          setcookie("etu[classe]","$classe",time()+1800, "/");
          setcookie("etu[id]","$id",time()+1800, "/");
          header("location: ../home/etudiant/index.php?classe=$classe");
        }
        else{
          echo "Mot de passe incorrect!";
        }
      }else if($type=='prof'){
        $requete = $this->_bdd->prepare('SELECT password, id FROM professeur WHERE nom=:nom AND prenom=:pnom ');
        $pass = $requete->execute(['nom'=>$nom,'pnom'=>$pnom]);
        $pass2 = $requete->fetchall();
        if($pass2['0']['password']==$this->_Password){
          session_start();
          $_SESSION['Type']='prof';
          $id = $pass2['0']['id'];
          setcookie("id_prof",$id,time()+1800, "/");
          header("location: ../home/professeur/index.php?id=$id");
        }
        else{
          echo "Mot de passe incorrect!";
        }
      }else{
        $requete = $this->_bdd->prepare('SELECT password FROM direction WHERE nom=:nom AND prenom=:pnom ');
        $pass = $requete->execute(['nom'=>$nom,'pnom'=>$pnom]);
        $pass2 = $requete->fetch();
        if($pass2['password']==$this->_Password){
          setcookie('user',$this->_Type,time()+3600);
          header('location: ../home/direction/');
        }
        else{
          echo "Mot de passe incorrect!";
        }
      }

    }
    //Fonction qui permet l'inscription d'un etudiant
    public function inscription(){
      $this->setBdd();
      $Nom = $this->_Nom;
      $Prenom = $this->_Prenom;
      $Classe = $this->_Classe;
      $Password = $this->_Password;
      $requete = $this->_bdd->prepare('INSERT INTO etudiant(nom,prenom,classe,absence,retard,password) VALUES (:nom, :pnom, :classe, :a, :r, :pass);');
      $resultat = $requete->execute(['nom'=>$Nom,'pnom'=>$Prenom,'classe'=>$Classe,'pass'=>$Password, 'a'=>'0', 'r'=>'0']);
    }

    //Fonction qui permet à la direction de voir la liste de tous les étudiants
    public function dirlisteetudiant(){
      $requete=$bdd->query("SELECT nom, prenom, absence, retard FROM etudiant ORDER BY nom;");
      $tableau=$requete->fetchall();
      return $tableau;
    }
    //Fonction qui permet à la direction de voir la liste de tous les étudiants en fonction de leur classe
    public function dirlisteetudiantparclasse(){
      $requete = $bdd->query("SELECT nom, prenom, absence, retard FROM etudiant WHERE classe=$this->_Classe ORDER BY nom;");
      $tableau = $requete->fetchall();
      return $tableau;
    }

    //Fonction qui permet au professeur d'ajouter un cours
    public function ajoutercours(){
      $this->setBdd();
      $Matiere = $this->_Matiere;
      $Contenu = $this->_Contenu;
      $Classe = $this->_Classe;
      $Id = $this->_Id;
      $requete = $this->_bdd->prepare('INSERT INTO cours(matiere, contenu, classe, id_prof) VALUES (:matiere, :contenu, :classe, :id);');
      $resultat = $requete->execute(['matiere'=>$Matiere,'contenu'=>$Contenu,'classe'=>$Classe, 'id'=>$Id]);
      header("location: ../espacecours.php?id=$Id");
    }

    public function modifiercours(){
      $this->setBdd();
      $Matiere = $this->_Matiere;
      $Contenu = $this->_Contenu;
      $Classe = $this->_Classe;
      $Id = $this->_Id;
      $requete = $this->_bdd->prepare('UPDATE cours SET matiere=:matiere, contenu=:contenu, classe=:classe WHERE id=:id;');
      $resultat = $requete->execute(['matiere'=>$Matiere,'contenu'=>$Contenu,'classe'=>$Classe, 'id'=>$Id]);
      $idprof = $_COOKIE['id_prof'];
      header("location: ../espacecours.php?id=$idprof");
    }

    //Fonction qui permet à la direction de noter l'absence d'un professeur
    public function dirabsenceprof(){
      $this->setBdd();
      $id = $this->_Id;
      $absence = $this->_bdd->prepare("SELECT absence FROM professeur WHERE id=:id;");
      $abs = $absence->execute(['id'=>$id]);
      $abs = $absence->fetch();
      $abs = $abs['absence'];
      $abs = $abs + 1;
      $update = $this->_bdd->prepare('UPDATE professeur SET absence=:abse WHERE id=:id;');
      $update->execute(['abse'=>$abs,'id'=>$id]);
      header('location: espaceprof.php');
    }

    public function absenceeleve(){
      $this->setBdd();
      $id = $this->_Id;
      $absence = $this->_bdd->prepare("SELECT absence FROM etudiant WHERE id=:id;");
      $abs = $absence->execute(['id'=>$id]);
      $abs = $absence->fetch();
      $abs = $abs['absence'];
      $abs = $abs + 1;
      $update = $this->_bdd->prepare('UPDATE etudiant SET absence=:abse WHERE id=:id;');
      $update->execute(['abse'=>$abs,'id'=>$id]);
      $id_prof = $_COOKIE['id_prof'];
      header("location: espaceeleve.php?id=$id_prof");
    }

    //Fonction qui permet au professeur de noter un élève en retard
    public function retardeleve(){
      $this->setBdd();
      $id = $this->_Id;
      $retard = $this->_bdd->prepare("SELECT retard FROM etudiant WHERE id=:id;");
      $rtd = $retard->execute(['id'=>$id]);
      $rtd = $retard->fetch();
      $rtd = $rtd['retard'];
      $rtd = $rtd + 1;
      $update = $this->_bdd->prepare('UPDATE etudiant SET retard=:rtd WHERE id=:id;');
      $update->execute(['rtd'=>$rtd,'id'=>$id]);
      $id_prof = $_COOKIE['id_prof'];
      header("location: espaceeleve.php?id=$id_prof");
    }

    //Fonction qui permet à la direction d'ajouter un professeur
    public function dirajouterprof(){
      $this->setBdd();
      $Nom=$this->_Nom;
      $Prenom=$this->_Prenom;
      $Password=$this->_Password;
      $requete = $this->_bdd->prepare("INSERT INTO professeur(nom,prenom,absence,password) VALUES (:Nom, :Prenom, 0, :Password);");
      $resultat = $requete->execute(['Nom'=>$Nom,'Prenom'=>$Prenom,'Password'=>$Password]);
      header('Location: ../espaceprof.php');
    }

    public function dirajouterdir(){
      $this->setBdd();
      $Nom=$this->_Nom;
      $Prenom=$this->_Prenom;
      $Password=$this->_Password;
      $requete = $this->_bdd->prepare("INSERT INTO direction(nom,prenom,password) VALUES (:Nom, :Prenom, :Password);");
      $resultat = $requete->execute(['Nom'=>$Nom,'Prenom'=>$Prenom,'Password'=>$Password]);
      var_dump($resultat);
      header('Location: ../espacedirection.php');
    }

    public function ajouteretu(){
      $this->setBdd();
      $Nom = $this->_Nom;
      $Prenom = $this->_Prenom;
      $Classe = $this->_Classe;
      $Password = $this->_Password;
      $requete = $this->_bdd->prepare('INSERT INTO etudiant(nom,prenom,classe,absence,retard,password) VALUES (:nom, :pnom, :classe, :a, :r, :pass);');
      $resultat = $requete->execute(['nom'=>$Nom,'pnom'=>$Prenom,'classe'=>$Classe,'pass'=>$Password, 'a'=>'0', 'r'=>'0']);
      header('Location: ../espaceeleve.php');
    }
    //Fonction qui permet à la direction de supprimer un professeur
    public function dirsupprimerprof(){
      $this->setBdd();
      $id = $this->_Id;
      $requete = $this->_bdd->prepare("DELETE FROM professeur WHERE id=:id;");
      $resultat = $requete->execute(['id'=>$id]);
      header('location: espaceprof.php');
    }

    public function dirsupprimerdir(){
      $this->setBdd();
      $id = $this->_Id;
      $requete = $this->_bdd->prepare("DELETE FROM direction WHERE id=:id;");
      $resultat = $requete->execute(['id'=>$id]);
      header('location: espacedirection.php');
    }

    public function supprimeretu(){
      $this->setBdd();
      $id = $this->_Id;
      $requete = $this->_bdd->prepare("DELETE FROM etudiant WHERE id=:id;");
      $resultat = $requete->execute(['id'=>$id]);
      header('location: espaceeleve.php');
    }

    public function supprimercours(){
      $this->setBdd();
      $id = $this->_Id;
      $requete = $this->_bdd->prepare("DELETE FROM cours WHERE id=:id;");
      $resultat = $requete->execute(['id'=>$id]);
      $val = $_COOKIE['id_prof'];
      header("location: espacecours.php?id=$val");
    }
    //Fonction qui permet à la direction de modifier un professeur
    public function dirmodifierprof(){
      $this->setBdd();
      $password = $this->_Password;
      $id = $this->_Id;
      $requete = $this->_bdd->prepare("UPDATE professeur SET password=:password WHERE id=:id;");
      $resultat = $requete->execute(['password'=>$password,'id'=>$id]);
      header("location: ../espaceprof.php");
    }

    public function modifieretu(){
      $this->setBdd();
      $password = $this->_Password;
      $id = $this->_Id;
      $classe = $this->_Classe;
      $requete = $this->_bdd->prepare("UPDATE etudiant SET password=:password, classe=:classe WHERE id=:id;");
      $resultat = $requete->execute(['password'=>$password,'id'=>$id,'classe'=>$classe]);
      $id_prof = $_COOKIE['id_prof'];
      header("location: ../espaceeleve.php?id=$id_prof");
    }

    public function dirmodifierdir(){
      $this->setBdd();
      $password = $this->_Password;
      $id = $this->_Id;
      $requete = $this->_bdd->prepare("UPDATE direction SET password=:password WHERE id=:id;");
      $resultat = $requete->execute(['password'=>$password,'id'=>$id]);
      header("location: ../espacedirection.php");
    }
  }

  //création d'une classe fille de la classe utilisateur
  class prof extends utilisateur{
    //définition de la table à utiliser
    protected function setType(){
      $this->_Type = 'prof';
    }
    //définition de la table à utiliser
    protected function setTab(){
      $this->_Tab = 'professeur';
    }

    // Un tableau de données doit être passé à la fonction (d'où le préfixe « array »).
    public function hydrate(array $donnee){
      foreach($donnee as $k=>$u){
        $methode='set'.ucfirst($k);     // On récupère le nom du setter correspondant à l'attribut.
        if(method_exists($this,$methode)){ // Si le setter correspondant existe.
          $this->$methode($u); //on appelle le   setter
        }
      }
    }
    //creation de ma fonction construct hydrate
    public function __construct(array $donnee){
      $this->hydrate($donnee);
      $this->setType();
      $this->setTab();
    }
  }

    //création d'une classe fille de la classe utilisateur
  class direction extends utilisateur{
      //définition de la table à utiliser
    protected function setType(){
      $this->_Type = 'dir';
    }
      //définition de la table à utiliser
    protected function setTab(){
      $this->_Tab = 'direction';
    }

    // Un tableau de données doit être passé à la fonction (d'où le préfixe « array »).
        public function hydrate(array $donnee){
          foreach($donnee as $k=>$u){
            $methode='set'.ucfirst($k);     // On récupère le nom du setter correspondant à l'attribut.
            if(method_exists($this,$methode)){ // Si le setter correspondant existe.
              $this->$methode($u); //on appelle le setter
            }
          }
        }
        //creation de ma fonction construct hydrate
    public function __construct(array $donnee){
      $this->hydrate($donnee);
      $this->setType();
      $this->setTab();
    }
  }

    //création d'une classe fille de la classe utilisateur
  class etudiant extends utilisateur{
    //définition de la table à utiliser
    protected function setType(){
      $this->_Type = 'etu';
    }
      //définition de la table à utiliser
    protected function setTab(){
      $this->_Tab = 'etudiant';
    }

    // Un tableau de données doit être passé à la fonction (d'où le préfixe « array »).
        public function hydrate(array $donnee){
          foreach($donnee as $k=>$u){
            $methode='set'.ucfirst($k);     // On récupère le nom du setter correspondant à l'attribut.
            if(method_exists($this,$methode)){ // Si le setter correspondant existe.
              $this->$methode($u); //on appelle le setter
            }
          }
        }
      //creation de ma fonction construct hydrate
    public function __construct(array $donnee){
      $this->hydrate($donnee);
      $this->setType();
      $this->setTab();
    }
  }
?>
