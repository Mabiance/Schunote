<?php
session_start();
?>

<?php include("../include/navbar01.php"); ?>

<link rel="stylesheet" href="../css/testpencil.css?<?= rand(); ?>">

<style>
  body {
    background: url("../images/connexion.jpg"); no-repeat center center fixed;
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    background-position: top 100px;
  }
</style>


<div style="padding-top: 270px;" class="d-block mx-auto col-md-4 col-xs-2">

    <div class="form-area text-center">
        <form id="form-contact" role="form" action="../traitement/connexion.php" method="post">
            <br style="clear:both">

            <div class="form-group">
                <input type="text" class="form-control" id="identifiant" name="nom" placeholder="Nom" required>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" id="identifiant" name="prenom" placeholder="Prénom" required>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" id="password" name="password" placeholder="Mot de passe" required>
            </div>
            <input type="radio" name="choix" id="choix1" value="1" required/><label class="radio-inline" for="choix1">Etudiant</label>
            <input type="radio" name="choix" id="choix2" value="0" required/><label class="radio-inline" for="choix2">Professeur</label>
            <input type="radio" name="choix" id="choix3" value="2" required/><label class="radio-inline" for="choix3">Direction</label>
<br><br><br>

            <button type="submit" id="submit" name="submit" class="btn btn-secondary">Connexion</button>
        </form>
    </div>

</div>

<div class="d-block mx-auto col-md-8 col-xs-6" style="padding-top: 220px;">


<?php include("../include/footer.php"); ?>
